use Opleidingen;
alter table Voorraden add Aangepast timestamp
go