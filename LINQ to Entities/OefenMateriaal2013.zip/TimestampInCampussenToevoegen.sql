use Opleidingen;
alter table Campussen add Aangepast timestamp
go