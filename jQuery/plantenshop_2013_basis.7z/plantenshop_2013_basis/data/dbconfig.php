<?php


class DBConfig {

	//geen instance van deze class wordt aangemaakt, dient enkel als container
	public static $host = "localhost";
	public static $dbUser = "web";
	public static $dbPassw = "web";
	public static $dbName = "plantenshop";


}

?>