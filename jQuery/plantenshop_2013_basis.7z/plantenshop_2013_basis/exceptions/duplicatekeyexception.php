<?php

class DuplicateKeyException extends Exception{
//mag zelf leeg blijven


}

?>