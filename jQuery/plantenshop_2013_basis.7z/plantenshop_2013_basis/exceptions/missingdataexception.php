<?php

class MissingDataException extends Exception{
//mag zelf leeg blijven


}

?>