﻿UPDATE [toysforboys].[dbo].[productlines]
  SET name = 'Classic Cars' WHERE name = 'Tlassic Cars';
  UPDATE [toysforboys].[dbo].[productlines]
  SET name = 'Motorcycles' WHERE name = 'Totorcycles';
  UPDATE [toysforboys].[dbo].[productlines]
  SET name = 'Planes' WHERE name = 'Tlanes';
  UPDATE [toysforboys].[dbo].[productlines]
  SET name = 'Ships' WHERE name = 'Thips'; 
  UPDATE [toysforboys].[dbo].[productlines]
  SET name = 'Vintage Cars' WHERE name = 'Tintage Cars';
